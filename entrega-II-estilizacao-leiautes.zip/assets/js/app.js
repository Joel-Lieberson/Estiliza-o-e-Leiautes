
// app.js — navigation + components
document.addEventListener('DOMContentLoaded', () => {
  // Hamburger
  const burger = document.querySelector('[data-burger]');
  const menu = document.querySelector('[data-menu]');
  if(burger && menu){
    burger.addEventListener('click', () => menu.classList.toggle('open'));
  }

  // Dropdown keyboard support
  document.querySelectorAll('.menu-item > a').forEach(a => {
    a.addEventListener('keydown', e => {
      if(e.key === 'Enter' || e.key === ' '){
        e.preventDefault();
        a.parentElement.querySelector('.submenu')?.classList.toggle('open');
      }
    });
  });

  // Modal
  const openModal = document.querySelectorAll('[data-open-modal]');
  const closeModal = document.querySelectorAll('[data-close-modal]');
  const backdrop = document.querySelector('.modal-backdrop');
  const root = document.documentElement;

  function setModal(open){
    if(!backdrop) return;
    if(open){ root.classList.add('modal-open'); }
    else{ root.classList.remove('modal-open'); }
  }
  openModal.forEach(btn => btn.addEventListener('click', (e) => { e.preventDefault(); setModal(true); }));
  closeModal.forEach(btn => btn.addEventListener('click', () => setModal(false)));
  backdrop?.addEventListener('click', (e) => { if(e.target === backdrop){ setModal(false); } });

  // Toast helper
  function showToast(msg){
    let t = document.querySelector('.toast');
    if(!t){
      t = document.createElement('div');
      t.className = 'toast';
      document.body.appendChild(t);
    }
    t.textContent = msg;
    t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), 3000);
  }

  // Form validation visuals
  const form = document.querySelector('form#form-cadastro');
  if(form){
    form.querySelectorAll('.form-control').forEach(input => {
      input.addEventListener('blur', () => {
        if(input.checkValidity()){
          input.classList.remove('is-invalid');
          input.classList.add('is-valid');
        }else{
          input.classList.add('is-invalid');
        }
      });
    });
    form.addEventListener('submit', (e) => {
      if(!form.checkValidity()){
        e.preventDefault();
        form.reportValidity();
        showToast('Por favor, corrija os campos destacados.');
      } else {
        e.preventDefault();
        showToast('Cadastro enviado com sucesso!');
      }
    });
  }
});
